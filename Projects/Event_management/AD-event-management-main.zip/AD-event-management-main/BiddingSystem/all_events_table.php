<html>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<?php	
	class TableRows extends RecursiveIteratorIterator {
	    function __construct($it) {
	        parent::__construct($it, self::LEAVES_ONLY);
	    }

	    function current() {
	        return "<td>" . parent::current(). "</td>";
	    }

	    function beginChildren() {
	        echo "<tr>";
	    }

	    function endChildren() {
	        echo "</tr>" . "\n";
	    }
	}
	require_once "pdo.php";
	$sql = "Select * from event_details";
			$stmt = $pdo->prepare($sql);
			$stmt->execute();
			// $row =  $stmt->fetchAll();
			echo "<table class = 'table table-hover' style= 'margin-left:50px'>";
			if ($stmt->rowCount() > 0 && isset($_SESSION['username']) ) {
				echo 
				"<thead><tr>
				<th>Id</th>
				<th>Type</th>
				<th>Username</th>
				<th>Area</th>
				<th>Attendees</th>
				<th>Budget</th>
				<th>Venue</th>
				<th>Date</th>
				<th>Description</th>
				<th>Bid</th>
				</thead>";
				while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
					// echo(htmlentities($row[1]));
					// print_r($row);
				    echo "<tr><td>";
				    echo(htmlentities($row['event_id']));
				    echo("</td><td>");
				    echo(htmlentities($row['event_type']));
				    echo("</td><td>");
				    echo(htmlentities($row['username']));
				    echo("</td><td>");
				    echo(htmlentities($row['location']));
				    echo("</td><td>");
				    echo(htmlentities($row['attendees']));
				    echo("</td><td>");
				    echo(htmlentities($row['budget']));
				    echo("</td><td>");
				    echo(htmlentities($row['venue_type']));
				    echo("</td><td>");
				    echo(htmlentities($row['duration']));
				    echo("</td><td>");
				    echo(htmlentities($row['description']));
				    echo("</td><td>");
			     // 	echo('<a href="edit.php?autos_id='.$row['autos_id'].'">Edit</a> / ');
				    // echo('<a href="delete.php?autos_id='.$row['autos_id'].'">Delete</a>');
				    // echo "<button onclick='location.href = "."\BiddingSystem\bidding_form.php;'"."' class=btn btn-outline-info float-end' style='margin-left: 2mm;'>Go Bid</button>";
				    ?>
				    <button onclick="<?php $_SESSION['bidding_event_id']= $row['event_id']?>;location.href = '\\BiddingSystem\\bidding_form.php';" class="btn btn-outline-info float-end" style="margin-left: 2mm;">Bid</button>
				    <?php
				    echo("</td></tr>");
				}

			}
 			// echo "<tr><th>Id</th><th>Username</th><th>Area</th><th>Attendees</th><th>Budget</th><th>Venue</th><th>Date</th><th>Type</th><th>Description</th></tr>";
 		// 	$temp = "";
			// foreach(new TableRows(new RecursiveArrayIterator($row)) as $k=>$v) {
			// 	if ($temp == $v){
			// 		continue;
			// 	}
			// 	$temp = $v;
			// 	print($v);
			// }
			echo "</table>";
?>

