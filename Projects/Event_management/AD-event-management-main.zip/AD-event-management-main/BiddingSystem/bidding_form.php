<html>

<?php
	require_once "pdo.php";
	require_once "../util.php";
	if (isset($_POST['abc'])){
		try{
            // echo " asdasd - " . $_SESSION["bidding_event_id"];
			$username = $_SESSION["username"];
			$event_id = $_SESSION["bidding_event_id"];
			
			$sql = "Select * from bid_details where username ='".$username."' and event_id =".$event_id;
			$stmt = $pdo->prepare($sql);
			$stmt->execute();
			$row =  $stmt->fetch(PDO::FETCH_ASSOC);
			if (!$row) {		// if there is noth
                // print_r($row);
				$sql = "INSERT INTO bid_details (username,event_id,amount,cover_letter,attachments) VALUES (:username,:event_id,:price,:note,:attachment)";
				$stmt = $pdo->prepare($sql);
                echo $_POST['attachment'];
				$stmt->execute(array(":username"=>$username,":event_id" => $event_id,':price' => $_POST['price'],':note' => $_POST['note'],':attachment' => $_POST['attachment']));
			}
			else{
				echo"<br>replication";
			} 
		}catch(Exception $e){
			echo "Working $e";
		}
	}
?>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<title></title>
</head>
<body>
<nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-dark">
    <div class="container-fluid">

        <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../HomePage/rishabh/index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../HomePage/rishabh/index.php#contact_us">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../HomePage/rishabh/index.php#contact_us">About Us</a>
                </li>
                <li class="nav-item mr-0">
                    <a class="nav-link" href="../Login/logout_client.php">Logout</a>
                </li>
            </ul>

        </div>
    </div>
</nav>
	<div>
		<form method="POST" action="" style="width: 80%;margin-left: 10%;">
			<legend>Bidding Form</legend>
			<div class="form-floating mb-3">
				<input type="Number" class="form-control" id="price" placeholder=" " name = "price">
				<label for="price">Price</label>
			</div>
			<div class="form-floating">
				<textarea class="form-control" id="note" placeholder=" " name="note"></textarea>
				<label for="note">Comments</label>
			</div>
			<br>
			<br>
			<div class="form-group">
				<label for="exampleFormControlFile1">Example file input</label>
				<input type="file" class="form-control-file" id="attachment exampleFormControlFile1" name = "attachment">
			</div>
			<br>
			<br>
			<input type = "submit" class="btn btn-primary" name = "abc"/>
			
		</form>
	</div>
</body>
</html>