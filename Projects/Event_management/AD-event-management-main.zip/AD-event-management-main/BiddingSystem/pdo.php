<?php
  $host="localhost";
  $port=3306;
  $socket="";
  $user="root";
  $password="root";
  $dbname="event_management";

  try {
	  $pdo = new PDO("mysql:host={$host};port={$port};dbname={$dbname}", $user, $password);
	  #echo "connection built";
    } catch (PDOException $e) {
       echo 'Connection failed: ' . $e->getMessage();
  }
?>