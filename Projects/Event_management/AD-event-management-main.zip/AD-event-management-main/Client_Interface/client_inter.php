<!-- drop table if exists event_details;
create table event_details(
event_id int(5) primary key auto_increment,
username varchar(30) not null,
location varchar(500) not null,
attendees int(5) not null,
budget float(10) not null,
venue_type varchar(30) not null,
duration timestamp not null,
event_type varchar(30) not null,
description varchar(1000) not null,
constraint fk_username_event_details foreign key (username) references users(username)
); -->
<?php
//include "conn_client_db.php";
require_once "../Tracking/pdo.php";

$name = htmlentities($_POST['name']);
$city = htmlentities($_POST['city']);
$attendees = htmlentities($_POST['attendees']);
$budget = htmlentities($_POST['budget']);
$venue_type = htmlentities($_POST['venue_type']);
$duration = htmlentities($_POST['duration']);
$time = htmlentities($_POST['time']);
$event_type = htmlentities($_POST['event_type']);
$description = htmlentities($_POST['description']);
#echo $_POST['image'];
#$image = htmlentities($_FILES['image']);
#$statusMsg = '';
    // File upload path
    #$targetDir = "uploads/";
   // $fileName = basename($_FILES["file"]["name"]);
    // $targetFilePath = $targetDir . $fileName;
    // $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
//echo"\r\n";
//echo $name;
if(isset($_POST['name']) && isset($_POST['city']) && isset($_POST['attendees']) 
&& isset($_POST['budget']) && isset($_POST['venue_type']) && isset($_POST['duration'])
&& isset($_POST['time']) && isset($_POST['event_type']) && isset($_POST['description'])
)
{

    try
    {
        // $sql = "INSERT INTO `event_details`( `username`, `location`, `attendees`, `budget`, `venue_type`, `duration`, `event_type`, `description`) 
        // VALUES ('$name','$city','$attendees','$budget','$venue_type','$duration','$event_type','$description')";
        $sql = "INSERT INTO `event_details`(`username`, `location`, `attendees`, `budget`, `venue_type`, `event_type`, `description`, `duration`) 
        VALUES (:name,:city,:attendees,:budget,:venue_type,:event_type,:description,:duration)";

       // $name,$city,$attendees,$budget,$venue_type,$time,$event_type,$description,$duration
        //$pdo->exec($sql);

       // echo "<h2>Thank you <b>$name</b> your <b>$event_type</b> event has been sucessfully posted...</h2>";
       // $sql = "INSERT INTO bid_details (username,event_id,amount,cover_letter,attachments) VALUES (:username,:event_id,:price,:note,:attachment)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array(":name"=>$name,":city" => $city,":attendees" => $attendees,":budget" => $budget,":venue_type" => $venue_type,":event_type"=>$event_type,":description"=>$description,":duration"=>$duration,));
    }

    catch(PDOException $e)
    {
        echo "Error in insertion " . $e->getMessage();
    }
}
echo "<br><button><a href='../RSVP/rsvpHome.html' style='text-decoration:none'>Send RSVP invites</a></button>";
?>