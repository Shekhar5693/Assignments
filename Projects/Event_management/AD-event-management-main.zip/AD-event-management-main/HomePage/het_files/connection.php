<?php
    $conn = mysqli_connect('localhost:3307','root','','test');
    if($conn){
       // echo 'Connected';
    }
    else{
        //echo 'Not connected';
    }
    
?>