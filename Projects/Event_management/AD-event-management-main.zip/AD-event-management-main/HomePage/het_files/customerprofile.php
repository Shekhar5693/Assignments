<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link href="../ad---2019-event-management/edits.css" rel="stylesheet">
    <title>Profile</title>
    <!--<script>
        $("#location_user").load(function(){
            
        }
        var x = document.getElementById("demo");
        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition);
            } else {
                x.innerHTML = "Geolocation is not supported by this browser.";
            }
        }

        function showPosition(position) {
            x.innerHTML = "Latitude: " + position.coords.latitude +
                "<br>Longitude: " + position.coords.longitude;
        }
    </script>
-->
</head>

<body>
    <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Event Management</a>

    </nav>
    <nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-dark">
        <div class="container-fluid">

            <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Hire</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Events
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Marriage</a></li>
                            <li><a class="dropdown-item" href="#">Birthday Celebration</a></li>
                            <li><a class="dropdown-item" href="#">Baby Shower</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                </ul>


                <form class="d-flex">

                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-warning" type="submit">Search</button>
                    <button class="btn btn-outline-success">Login</button>
                    <button class="btn btn-outline-danger">SignUp</button>

                </form>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="border-bottom" style="padding-top: 1cm;">
            <div class="row gx-5">
                <div class="col">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php include 'output.php';  ?>
                    </a>
                </div>

                <div class="col">
                    <img class="dropdown-toggle" src="" alt="PROFILE">

                </div>
            </div>
        </div>

        <hr>


        <div class="row" style="padding-top: 1cm;">
            <div class="col-sm-6" style="padding-top: 1mm;">
                <div class="card btn setbtn">
                    <div class="card-body">
                        <h5 class="card-title">Your Dash</h5>
                        <p class="card-text">Check your status.</p>

                    </div>
                </div>
            </div>
            <div class="col-sm-6" style="padding-top: 1mm;">
                <div class="card btn setbtn">
                    <div class="card-body">
                        <h5 class="card-title">Login & Security</h5>
                        <p class="card-text">Edit your profile and security.</p>

                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="padding-top: 1cm;">
            <div class="col-sm-6" style="padding-top: 1mm;">
                <div class="card btn setbtn">
                    <div class="card-body">
                        <h5 class="card-title">Payment Opps</h5>
                        <p class="card-text">Modify payment options.</p>

                    </div>
                </div>
            </div>
            <div class="col-sm-6" style="padding-top: 1mm;">
                <div class="card btn setbtn">
                    <div class="card-body">
                        <h5 class="card-title">Membership</h5>
                        <p class="card-text">Add or remove you Membership or Check the status.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW"
        crossorigin="anonymous"></script>
    -->
    <!-- Option 2: Separate Popper and Bootstrap JS -->

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"
        integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"
        integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj"
        crossorigin="anonymous"></script>




</body>

</html>