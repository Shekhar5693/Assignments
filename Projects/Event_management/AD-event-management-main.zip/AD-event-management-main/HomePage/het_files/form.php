<html>

<body>
    
    <center>
        <form method="post" action="input.php">
            <b>Name: </b>
            <input type="text" id="uname" name="uname" placeholder="Enter Your Name">
            <b> Password: </b>
            <input type="text" id="pass" name="pass" placeholder="Enter Your Password">
            <input type="submit" id="form" name="form">
        </form>
    </center>

</body>

</html>