<?php

include 'connection.php';

$uname = $_POST['uname'];
$pass = $_POST['pass'];

$sql = "INSERT INTO testinfo (uname, pass) VALUES ('$uname','$pass')";
$rs = mysqli_query($conn,$sql);

?>