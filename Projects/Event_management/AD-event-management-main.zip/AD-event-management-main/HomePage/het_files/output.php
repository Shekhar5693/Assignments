<?php
    
    include 'connection.php';
    $output = mysqli_query($conn,"SELECT uname FROM testinfo ");

    $data = mysqli_fetch_assoc($output);
    echo $data['uname'];
    
?>