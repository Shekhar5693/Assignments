<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
// define("DB_SERVER", "127.0.0.1:3307");
// define("DB_USERNAME", "root");
// define("DB_PASSWORD", "");
// define("DB_NAME", "event_management");
 
// /* Attempt to connect to MySQL database */
// $link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// // Check connection
// if($link === false){
//     die("ERROR: Could not connect. " . mysqli_connect_error());
// }
?>


<?php
$servername = "localhost";
$username = "root";
$password = "RISHABHp@15";
$db_name = "event_management";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$db_name", $username, $password);
  // set the PDO error mode to exception
  // $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // echo "Connected successfully<br>";
  // $stmt = $conn->query("SELECT * FROM student_info");

  // echo "<table border='1'>";
  // while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
  //     echo "<tr> <td>" . $row['sr_no'] . "</td> <td>" . $row['name'] . "</td> <td>" . $row['email_id'] . "</td> </tr>";
  //   }
  // echo "</table>";
  echo "hi";
  
} catch(PDOException $e) {
    phpinfo(pdo_mysql);
  echo "Connection failed: " . $e->getMessage();
//   mysqli_close($conn);
}

?> 