<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Event Management</title>
    <style>
        a{
            text-decoration: none;
            color : white;
        }
        a:hover {
            color: white;
        }
        h5{
            text-align: center;
        }
    </style>
</head>

<body>

    <nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Event Management</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Hire</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Events
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Marriage</a></li>
                            <li><a class="dropdown-item" href="#">Birthday Celebration</a></li>
                            <li><a class="dropdown-item" href="#">Conference</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact_us">Contact Us</a>
                    </li>
                </ul>
                <form class="d-flex">
                 
                    <button class="btn btn-outline-info me-2"> <a href="../../Login/main_login.php"> Login</a> </button>
                    <button class="btn btn-outline-info me-2"> <a href="../../Login/main_signup.php"> SignUp </a></button>
                </form>
            </div>
        </div>
    </nav>

    <br>
    <div id="carouselExampleCaptions" class="carousel slide carousel-fade p-5" data-bs-ride="carousel">
        <ol class="carousel-indicators">
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"></li>
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="marr.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Marriage </h5>
                    <p></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="marr2.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://source.unsplash.com/1000x400/?Marriage" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </a>
    </div>
    <div class="card border-secondary mb-3 text-center mx-auto" style="max-width: 18rem;" >
        <div class="card-body" >
            <a href="#" class="link-success">
                <h5 class="card-title" >Marriage</h5>
            </a>
            <p class="card-text"></p>
        </div>
    </div>

    <div id="carouselExampleCaptions" class="carousel slide carousel-fade p-5" data-bs-ride="carousel">
        <ol class="carousel-indicators">
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"></li>
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="birt1.jpg.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Birthday</h5>
                    <p></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="birt2.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://source.unsplash.com/1000x400/?Birthday" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </a>
    </div>
    <div class="card border-success mb-3 text-center mx-auto" style="max-width: 18rem;" >
        <div class="card-body" class="center">
            <a href="#" class="link-success">
                <h5 class="card-title">Birthday Celebration</h5>
            </a>
            <p class="card-text"></p>
        </div>
    </div>

    <div id="carouselExampleCaptions" class="carousel slide carousel-fade p-5" data-bs-ride="carousel">
        <ol class="carousel-indicators">
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"></li>
            <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="caro-con.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Conference</h5>
                    <p></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://source.unsplash.com/1000x400/?Conference" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://source.unsplash.com/1000x400/?Conference" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </a>
    </div>
    <div class="card border-danger mb-3 text-center mx-auto" style="max-width: 18rem;" >
        <div class="card-body" class="center">
            <a href="#" class="link-success">
                <h5 class="card-title">Conference</h5>
            </a>
            <p class="card-text"></p>
        </div>
    </div>

    <div class="p-3 mb-2 bg-transparent text-dark"></div>
    <div class="container text-center">
        <a class="container" href="index.css"></a>
        <ul id="contact_us" class="social-menu list-inline mb-0">
            <li id="menu-item-357"
                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-357 list-inline-item mr-0">
                <a title="Twitter" href="#" class="link-success"><img src="tw.jpg" height="30" width="30">Twitter</a>
            </li>
            <li id="menu-item-358"
                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-358 list-inline-item mr-0">
                <a title="Facebook" href="#" class="link-success"><img src="fa.jpg" height="25" width="25"> Facebook</a>
            </li>
            <li id="menu-item-359"
                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-359 list-inline-item mr-0">
                <a title="Instagram" href="#" class="link-success"><img src="in.jpg" height="25" width="25">
                    Instagram</a>
            </li>
        </ul>
        <!--<a href="contact_us.php" class="btn btn-primary btn-lg" role="button">Further Contact</a> -->
    </div>
    <!-- <div class="p-3 mb-2 bg-transparent text-dark"></div> -->
    <footer class="container-fluid text-center">
        <p class="float-end"><a href="#"><img src="back.jpg" height="40" width="40"></a></p>
        <p>© 2020-2021 EM, Inc. ·</p>
    </footer>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous">
    </script>
</body>

</html>