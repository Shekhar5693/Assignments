<?php
$servername = "localhost";
$username = "root";
$password = "root";
$db_name = "event_management";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$db_name", $username, $password);
  // set the PDO error mode to exception
  // $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // echo "Connected successfully<br>";
  // $stmt = $conn->query("SELECT * FROM student_info");

  // echo "<table border='1'>";
  // while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
  //     echo "<tr> <td>" . $row['sr_no'] . "</td> <td>" . $row['name'] . "</td> <td>" . $row['email_id'] . "</td> </tr>";
  //   }
  // echo "</table>";

  
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
  mysqli_close($conn);
}

?> 