<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    //    header("location: ../../HomePage/rishabh/index.php");
    header("location: ../Templates/het_files/managerdash.php");
    //header("location: welcome_client.php");
    exit;
}

// Include config file
require_once 'dbconnect.php';
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if username is empty
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter username.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Check if password is empty
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate credentials
    if (empty($username_err) && empty($password_err)) {
        // Prepare a select statement
        $sql = "SELECT username, password FROM users WHERE username = :username";

        if ($stmt = $conn->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);

            // Set parameters
            $param_username = trim($_POST["username"]);

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Check if username exists, if yes then verify password
                if ($stmt->rowCount() == 1) {
                    if ($row = $stmt->fetch()) {
                        $username = $row["username"];
                        $hashed_password = $row["password"];
                        echo "password : " . $hashed_password;
                        if (strcmp($password, $hashed_password) == 0) {
                            // Password is correct, so start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["username"] = $username;

                            // Redirect user to welcome page
                            header("location: ../HomePage/het_files/managerdash.php");
                        } else {
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid password.";
                        }
                    }
                } else {
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username .";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }

    // Close connection
    unset($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href=".css/css_file.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-dark">
    <div class="container-fluid">

        <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../HomePage/rishabh/index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../HomePage/rishabh/index.php#contact_us">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../HomePage/rishabh/index.php#contact_us">About Us</a>
                </li>
            </ul>

        </div>
    </div>
</nav>

<body>
<div class="container-fluid text-center mt-5 w-100">
    <form class="signup" method="post" style="margin:0 auto">
        <h1>Login as Event-Manager</h1>
        <h2>Don't have an account? <span><a href="signup_event-manager.php">Sign Up</a></span></h2>

        <?php
        if (!empty($login_err)) {
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }
        ?>


        <div class="signup__field">
            <input type="text" name="username" class="signup__input <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
            <label class="signup__label">Username</label>
            <span class="help-block"><?php echo $username_err; ?></span>
        </div>
        <div class="signup__field">

            <input type="password" name="password" class="signup__input <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
            <label class="signup__label">Password</label>
            <span class="help-block"><?php echo $password_err; ?></span>
        </div>
        <button class="btn btn-default" value="Submit"> Submit </button>
    </form>
</div>
</body>

</html>