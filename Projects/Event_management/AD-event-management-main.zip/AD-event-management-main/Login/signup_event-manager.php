<?php
// Include config file
//require_once '../admin-charts/dbconnect.php';
require_once 'dbconnect.php';

// Define variables and initialize with empty values
$username = $password = $confirm_password = $mobile_no = $email = $name = $user_type = $timestamp = "";
$username_err = $password_err = $confirm_password_err = $email_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $username_err = "Please enter a email.";
    } else {
        // Prepare a select statement
        $sql = "SELECT email FROM users WHERE email = :email";

        if ($stmt = $conn->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);

            // Set parameters
            $param_email = trim($_POST["email"]);

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    $email_err = "This email is already taken.";
                } else {
                    $email = trim($_POST["email"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }


    // Validate username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } else {
        // Prepare a select statement
        $sql = "SELECT username FROM users WHERE username = :username";

        if ($stmt = $conn->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);

            // Set parameters
            $param_username = trim($_POST["username"]);

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    $username_err = "This username is already taken.";
                } else {
                    $username = trim($_POST["username"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have atleast 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }

    // Check input errors before inserting in database
    if (empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($email_err)) {
        $date = date('Y-m-d H:i:s');
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password, mobile_no, email, name, user_type, timestamp) 
		VALUES (:username, :password, :mobile_no, :email, :name, 'Cient', '$date')";
        if ($stmt = $conn->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
            $stmt->bindParam(":password", $param_password, PDO::PARAM_STR);
            $stmt->bindParam(":mobile_no", $param_mobile_no, PDO::PARAM_STR);
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            $stmt->bindParam(":name", $param_name, PDO::PARAM_STR);


            // Set parameters
            $param_username = $username;
            // $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $param_password = $password;
            $param_mobile_no = trim($_POST["mobile_no"]);
            $param_email = $email;
            $param_name = trim($_POST["name"]);

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Redirect to login page
                header("location: login_event-manager.php");
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }

    // Close connection
    unset($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href=".css/css_file.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-dark">
    <div class="container-fluid">

        <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../HomePage/rishabh/index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../HomePage/rishabh/index.php#contact_us">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../HomePage/rishabh/index.php#contact_us">About Us</a>
                </li>
            </ul>

        </div>
    </div>
</nav>
<body>
    <div class="container-fluid text-center mt-5 w-100">
        <form class="signup" style="margin:0 auto" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">


            <h1>Create account as Event Manager</h1>
            <h2>Already have an account? <span><a href="login_event-manager.php">Login here</a></span></h2>
            <div class="signup__field">
                <input type="text" name="name" class="signup__input">
                <label class="signup__label">Name</label>
                <span class="help-block"></span>
            </div>

            <div class="signup__field">
                <input type="text" name="username" class="signup__input <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <label class="signup__label">Username</label>
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>

            <div class="signup__field">
                <input type="text" name="email" class="signup__input <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                <label class="signup__label">Email</label>
                <span class="help-block"><?php echo $email_err; ?></span>
            </div>

            <div class="signup__field">
                <input type="password" name="password" class="signup__input <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <label class="signup__label">Password</label>
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="signup__field">
                <input type="password" name="confirm_password" class="signup__input <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                <label class="signup__label">Confirm Password</label>
                <span class="help-block"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="signup__field">
                <input type="number" name="mobile_no" class="signup__input" max="9999999999" min="1111111111">
                <label class="signup__label">Number</label>
                <span class="help-block"></span>
            </div>


            <button value="Submit"> Submit </button>
            <br>
            <button value="Reset"> Reset</button>

        </form>
    </div>

</body>

</html>