Hello guys !! 
<br>
Welcome to <b>Event Management</b> group.

JUST RUN FRESH.PHP FROM htdocs!<br>
<em>Voila!!</em>DATABASE CREATED...

1) Login, signup(as event manager and customer as well as security)   (DHVANI, AAYUSHI)
2) Client form interface (DEVANSHI,PRIYA)
3) Dash board - (admin,event-manager,customer)  (YOGESH,HET,ARYAN)
4) Event manager - bidding system (DEV,RAJ)
5) Membership, payment gateway (PANAM)
6) Tracking system/Chat (SANKET B.)
7) RSVP - email  - security  (RUSHIL.PRO)
8) Bidding form (PRIYANK,MIT)
9) Admin system (business) (ARSLAAN)
10) Admin system(data analysis) (YOGESH)
11)Home page design and working(landing page) (upwork/freelancer)  (HET, RISHABH)



Login-SignUp 
Table(2) - Users[username,name,email,pass,dp,mobile,UserType]
	   ManagerDetails[Address,Company,EventTypes,photos,areaCovered,bids]
	    
Client form interface
Table(1) - EventDetails[event_id,location,attendees,budget,venueType,duration,eventType,description]

Event Manager (Bidding System)
Tables(1) - BidDetails[Bid,managerDetailId(fk),coverLetter,eventDetail(fk),attachments], 

Membership, payment gateway
Tables(1) - Membership[username(fk),PaymentDate,Duration,Amount]

Tracking system
Tables(2) - EventStatus[eventId(fk),isStarted,isLocationDec,isDecorated,isCompleted],
	    Chat Details[timeStamp,username(fk),message]

Admin system(data analysis) 
Tables(1) - Reviews[managerId(fk),eventDetail(fk),Username(fk),rating,review,photos] 

![Schema](https://user-images.githubusercontent.com/56973819/105636715-98b0f400-5e8f-11eb-8638-08424c2ea336.PNG)
