<html>
    <head>
        <title>Guest Form - Bring your Buddy</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
        <style>
            td {
                width: 90px;
            }
        </style>
    </head>
    <body>
        <nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-dark">
            <div class="container-fluid">

                <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Hire</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Events
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Marriage</a></li>
                                <li><a class="dropdown-item" href="#">Birthday Celebration</a></li>
                                <li><a class="dropdown-item" href="#">Baby Shower</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">About Us</a>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <ul class="navbar-nav mr-auto ">
                            <li class="nav-item ">
                                <a class="nav-link" href="#" onclick="getLocation()" id="demo"> Location</a>
                                <script>
                              var x = document.getElementById("demo");
                              function getLocation() {
                                  if (navigator.geolocation) {
                                      navigator.geolocation.getCurrentPosition(showPosition);
                                  } else {
                                      x.innerHTML = "Geolocation is not supported by this browser.";
                                  }
                              }

                              function showPosition(position) {
                                  x.innerHTML = "Latitude: " + position.coords.latitude +
                                      "<br>Longitude: " + position.coords.longitude;
                              }
                          </script>

                        </ul>
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-warning" type="submit">Search</button>
                        <button class="btn btn-outline-success">Login</button>
                        <button class="btn btn-outline-danger">SignUp</button>

                    </form>

                </div>
            </div>
        </nav>
        <div style="width:400px; margin-right: auto; margin-left: auto">
            <form class="form-signin" method="post" action="postData.php" style="margin-top: 80px">
                <input type="hidden" name="invite" value="DUO">
                <div class="text-center mb-4">
                    <h1 class="h3 mb-3 font-weight-normal">Bring your Buddy</h1>
                </div>
                <div class="form-floating mb-3">
                    <input type="name" id="name" name="name" class="form-control" placeholder="Name" required autofocus>
                    <label for="name">Name</label>
                </div>
                <div class="form-floating mb-3">
                    <p>Would you be attending the event?</p>
                    <div class="input-group">
                        <table style="text-align: center">
                            <tr>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" id="Yes" name="attending" value="Yes" >
                                        <label class="btn btn-secondary" for="Yes">&emsp;Yes&emsp;</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" id="No" name="attending" value="No" aria-label="Radio button for following text input">
                                        <label class="btn btn-secondary" for="No">&emsp;No&emsp;</label>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="form-floating mb-3 foodPref">
                    <p>Choose your food preference:</p>
                    <div class="input-group">
                        <table style="text-align: center">
                            <tr>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" name="foodPref" value="Indian" id="Indian">
                                        <label class="btn btn-secondary" for="Indian" style="width: 132px">Indian</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" name="foodPref" value="Italian" id="Italian">
                                        <label class="btn btn-secondary" for="Italian" style="width: 132px">Italian</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" name="foodPref" value="Thai" id="Thai">
                                        <label class="btn btn-secondary" for="Thai" style="width: 132px">Thai</label>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" name="foodPref" value="French" id="French">
                                        <label class="btn btn-secondary" for="French" style="width: 132px">French</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" name="foodPref" value="Mexican" id="Mexican">
                                        <label class="btn btn-secondary" for="Mexican" style="width: 132px">Mexican</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" name="foodPref" value="Chinese" id="Chinese">
                                        <label class="btn btn-secondary" for="Chinese" style="width: 132px">Chinese</label>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" name="foodPref" value="Other" id="Other">
                                        <label class="btn btn-secondary" for="Other" style="width: 400px">Other</label>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="form-floating mb-3 foodPref">
                    <input type="name" id="otherCuisine" name="otherCuisine" class="form-control" placeholder="Other cuisine" required autofocus>
                    <label for="otherCuisine">Other cuisine</label>
                </div>
                <div class="form-floating mb-3">
                    <p>Would you be accompanied with someone?</p>
                    <div class="input-group">
                        <table style="text-align: center">
                            <tr>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" id="Yes" name="plusOne" value="Yes" aria-label="Radio button for following text input" >
                                        <label class="btn btn-secondary" for="Yes">&emsp;Yes&emsp;</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group-prepend">
                                        <input class="btn-check" type="radio" id="No" name="plusOne" value="No" aria-label="Radio button for following text input">
                                        <label class="btn btn-secondary" for="No">&emsp;No&emsp;</label>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="form-floating mb-3">
                    <input type="name" id="plusOneName" name="plusOneName" class="form-control" placeholder="Name of your guest" required autofocus>
                    <label for="plusOneName">Name of your guest</label>
                </div>
                <div class="form-floating mb-3 radioMsg">
                    <input type="name" id="specialMsg" name="message" class="form-control" placeholder="Would you like to leave a special message?" required autofocus>
                    <label for="specialMsg" id="message">Would you like to leave a special message?</label>
                </div>
                <button class="btn btn-lg btn-primary btn-block" type="submit" style="width: 400px">Submit</button>
            </form>
        </div>
    </body>
</html>
