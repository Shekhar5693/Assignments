<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "event_management";
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
else
{
    $sql = ("SELECT COUNT(*) FROM guest_list");
    $rs = mysqli_query($conn, $sql);
    $result = mysqli_fetch_array($rs);
    echo $result[0];
}
?>
