<html>
<head>
    <title>Guest List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
</head>
<body>
    <nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Hire</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Events
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Marriage</a></li>
                            <li><a class="dropdown-item" href="#">Birthday Celebration</a></li>
                            <li><a class="dropdown-item" href="#">Baby Shower</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                </ul>
                <form class="d-flex">
                    <ul class="navbar-nav mr-auto ">
                        <li class="nav-item ">
                            <a class="nav-link" href="#" onclick="getLocation()" id="demo"> Location</a>
                            <script>
                          var x = document.getElementById("demo");
                          function getLocation() {
                              if (navigator.geolocation) {
                                  navigator.geolocation.getCurrentPosition(showPosition);
                              } else {
                                  x.innerHTML = "Geolocation is not supported by this browser.";
                              }
                          }

                          function showPosition(position) {
                              x.innerHTML = "Latitude: " + position.coords.latitude +
                                  "<br>Longitude: " + position.coords.longitude;
                          }
                      </script>

                    </ul>
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-warning" type="submit">Search</button>
                    <button class="btn btn-outline-success">Login</button>
                    <button class="btn btn-outline-danger">SignUp</button>

                </form>

            </div>
        </div>
    </nav>
<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "event_management";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM guest_list";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    ?>
    <div>
        Total guests: <span id='userCount'></span>
    </div>
    <h2><br>Guest List</h2>
    <span id='guestList'></span>
  <?php
} else {
  echo "No invitee has responded to your RSVP yet";
}
$conn->close();
?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
$(function() {
    function updateUserCount() {
        $('#userCount').load('countGuests.php');
        $('#guestList').load('guestList.php');
    }
    setInterval(updateUserCount, 1000);
});
</script>
</body>
</html>
