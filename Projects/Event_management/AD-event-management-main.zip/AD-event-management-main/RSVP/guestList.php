<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "event_management";
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
else
{
    $sql = ("SELECT * FROM guest_list");
    $result = $conn->query($sql);
    echo "<div class='table-responsive'><table class='table table-striped table-sm'><thead><tr><th>Invite type</th><th>Name</th><th>Status</th><th>Count</th><th>Guest Name</th><th>Food preference</th><th>Other cuisine</th><th>Message</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>" . $row["invite_type"] . "</td><td>" . $row["guest_name"] . "</td><td>" . $row["guest_status"] . "</td><td>" . $row["guest_count"]. "</td><td>" . $row["guest_one"] . "</td><td>" . $row["food_pref"] . "</td><td>" . $row["other_cuisine"] . "</td><td>" . $row["message"] . "</td></tr>";
    }
    echo "</tbody></table></div>";
}
?>
