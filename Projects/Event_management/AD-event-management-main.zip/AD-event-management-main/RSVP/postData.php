<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "event_management";
$connection = new mysqli($host, $dbUsername, $dbPassword, $dbName);
?>
<html>
    <head>
        <title>Thank you!</title>
        <link rel="stylesheet" href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://getbootstrap.com/docs/4.0/examples/floating-labels/floating-labels.css">
    </head>
    <body>
<?php
$invite = $_POST["invite"];
if ($invite == "SINGLE")
{
    $name = $_POST["name"];
    $attending = $_POST["attending"];
    $foodPref = $_POST["foodPref"];
    $otherCuisine = $_POST["otherCuisine"];
    $message = $_POST["message"];

    if ($connection->connect_error)
    {
        die('Connection error = '.$connection->connect_error);
    }
    else
    {
        $stmt = $connection->prepare("insert into guest_list (invite_type, guest_name, guest_status, food_pref, other_cuisine, message) values ('$invite','$name','$attending','$foodPref','$otherCuisine','$message')");
        $stmt->execute();
        $stmt->close();
        $connection->close();
        ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <h4 class="alert-heading">Thank you!</h4>
            <p><br>Hello <strong><?php echo $name; ?>,</strong> your response has been submitted successfully <br> to the event organizer. We'll make sure they reach out to you!</p>
            <hr>
            <a href="http://localhost:8080/ad/Templates/aryanDASHBOARD/examples/dashboard.php"><button class="btn btn-primary">Back to dashboard</button></a>
            <button onclick="closePopup()" type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php
    }
}
else if ($invite == "DUO")
{
    $name = $_POST["name"];
    $attending = $_POST["attending"];
    $foodPref = $_POST["foodPref"];
    $otherCuisine = $_POST["otherCuisine"];
    $guestName = $_POST["plusOneName"];
    $message = $_POST["message"];

    if ($connection->connect_error)
    {
        die('Connection error = '.$connection->connect_error);
    }
    else
    {
        $stmt = $connection->prepare("insert into guest_list (
            invite_type, guest_name, guest_status, guest_one, food_pref, other_cuisine, message) values ('$invite','$name','$attending','$guestName','$foodPref','$otherCuisine','$message')");
        $stmt->execute();
        $stmt->close();
        $connection->close();
        ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <h4 class="alert-heading">Thank you!</h4>
            <p><br>Hello <strong><?php echo $name; ?>,</strong> your response has been submitted successfully <br> to the event organizer. We'll make sure they reach out to you!</p>
            <hr>
            <a href="http://localhost:8080/ad/Templates/aryanDASHBOARD/examples/dashboard.php"><button class="btn btn-primary">Back to dashboard</button></a>
            <button onclick="closePopup()" type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php
    }
}
else if ($invite == "FAMILY")
{
    $name = $_POST["name"];
    $attending = $_POST["attending"];
    $guests = $_POST["guests"];
    $foodPref = $_POST["foodPref"];
    $otherCuisine = $_POST["otherCuisine"];
    $message = $_POST["message"];

    if ($connection->connect_error)
    {
        die('Connection error = '.$connection->connect_error);
    }
    else
    {
        $stmt = $connection->prepare("insert into guest_list (invite_type, guest_name, guest_status, guest_count, food_pref, other_cuisine, message) values ('$invite','$name','$attending','$guests','$foodPref','$otherCuisine','$message')");
        $stmt->execute();
        $stmt->close();
        $connection->close();
        ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <h4 class="alert-heading">Thank you!</h4>
            <p><br>Hello <strong><?php echo $name; ?>,</strong> your response has been submitted successfully <br> to the event organizer. We'll make sure they reach out to you!</p>
            <hr>
            <a href="http://localhost:8080/ad/Templates/aryanDASHBOARD/examples/dashboard.php"><button class="btn btn-primary">Back to dashboard</button></a>
            <button onclick="closePopup()" type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php
    }
}
?>
<script>
        function closePopup() {
            window.location = "http://localhost:8080/ad/Templates/aryanDASHBOARD/examples/dashboard.php";
        }
        </script>
    </body>
</html>
