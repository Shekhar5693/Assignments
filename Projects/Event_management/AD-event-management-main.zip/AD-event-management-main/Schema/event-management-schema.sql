create database event_management;
use event_management;

drop table if exists users;
create table users(
	username varchar(30) primary key,
	name varchar(30) not null,
	email varchar(30) not null,
	password varchar(50) not null,
	dp varchar(100) null,
	mobile_no varchar(12) not null,
	user_type varchar(30) not null,
	admin_status bool null,
	timestamp date
);

drop table if exists membership;
create table membership(
	`u_name` varchar(30) DEFAULT NULL,
	`pay_date` date DEFAULT NULL,
	`dur` int DEFAULT NULL,
	`due_date` date DEFAULT NULL,
	`amt` bigint DEFAULT NULL,
	`recur` tinyint(1) DEFAULT NULL,
	constraint fk_username_membership foreign key (u_name) references users(username)
);

drop table if exists event_manager_details;
create table event_manager_details(
	username varchar(30) not null,
	address varchar(500) not null,
	company varchar(30) not null,
	event_types varchar(50) not null,
	photos mediumblob not null,
	area_covered varchar(30) not null,
	constraint fk_username_event_manager_details foreign key (username) references users(username)
);

drop table if exists event_details;
create table event_details(
	event_id int(5) primary key auto_increment,
	username varchar(30) not null,
	location varchar(500) not null,
	attendees int(5) not null,
	budget float(10) not null,
	venue_type varchar(30) not null,
	duration int(10) not null,
	time timestamp not null,
	event_type varchar(30) not null,
	description varchar(1000) not null,
	image mediumblob not null,
	constraint fk_username_event_details foreign key (username) references users(username)
);

drop table if exists bid_details;
create table bid_details(
	bid_id int(5) primary key auto_increment,
	username varchar(30) not null,
	event_id int(5) not null,
	amount float(10) not null,
	cover_letter varchar(1000) not null,
	attachments mediumblob not null,
	constraint fk_username_bid_details foreign key (username) references users(username),
	constraint fk_event_id_bid_details foreign key (event_id) references event_details(event_id)
);

drop table if exists guest_list;
create table guest_list(
	event_id int(5) DEFAULT NULL,
    event_hash varchar(100) DEFAULT NULL,
    invite_type varchar(10) NOT NULL,
    guest_name varchar(50) NOT NULL,
    guest_status varchar(5) NOT NULL,
    guest_count int(5) NOT NULL,
    guest_one varchar(30) DEFAULT NULL,
    food_pref varchar(20) NOT NULL,
    other_cuisine varchar(20) DEFAULT NULL,
    message varchar(40) DEFAULT NULL
	constraint fk_event_id_guest_list foreign key (event_id) references event_details(event_id)
);

drop table if exists event_status;
create table event_status(
	event_id int(5) not null,
	is_location_dec boolean not null default 0,
	is_started boolean not null default 0,
	is_decorated boolean not null default 0,
	is_completed boolean not null default 0,
	constraint fk_event_id_event_status foreign key (event_id) references event_details(event_id)
);

drop table if exists chat_details;
create table chat_details(
	username varchar(30) not null,
	time timestamp not null,
	message varchar(1000),
	constraint fk_username_chat_details foreign key (username) references users(username)
);

drop table if exists reviews;
create table reviews(
	username varchar(30) not null,
	event_id int(5) not null,
	rating int(2) not null,
	review varchar(500) not null,
	photos mediumblob not null,
	constraint fk_username_reviews foreign key (username) references users(username),
	constraint fk_event_id_reviews foreign key (event_id) references event_details(event_id)
);
