<?php 
include 'navbar.php';
// include 'index.html';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin DashBoard</title>
  <link rel="stylesheet" href="../../static/Plugins/BootStrap/bootstrap.min.css">
  <link rel="stylesheet" href="../../static/AdminDashBoard/index.css">
  <link rel="stylesheet" href="../../static/Plugins/AOS/aos.css">
  <link rel="stylesheet" href="../../static/AdminDashboard/base.css">
  <script src="../../static/Plugins/Jquery/jquery.min.js"></script>
  <script src="../../static/Plugins/BootStrap/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
  <script src="../../static/Plugins/AOS/aos.js"></script>
  <script src="../../static/AdminDashBoard/app.js"></script>
</head>

<body>
  <div class="container-fluid" data-aos="fade-down">
    <div class="row">
      <div class="col-2 mt-5" style="position: fixed;" data-aos="fade-up" data-aos-delay="150">  <!--Accordion -->
        <div class="accordion" id="accordionExample">
          <div class="card">
            <div class="card-header" id="headingOne">
              <h2 class="mb-0 text-center">
                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  Event Managers
                </button>
              </h2>
            </div>
        
            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
              <div class="card-body text-center">
                <a href="">Manager Details </a> <hr>
                <a href="">Manager Progress </a>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header" id="headingTwo">
              <h2 class="mb-0 text-center">
                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  Customers
                </button>
              </h2>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
              <div class="card-body text-center">
                <a href="">Customer Details</a> <hr>
                <a href="">Customer Progress </a>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header" id="headingThree">
              <h2 class="mb-0 text-center">
                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  Admins
                </button>
              </h2>
            </div>
            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
              <div class="card-body text-center">
                <a href="">Admin Details</a> <hr>
                <a href="">All Users </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-10 ml-auto" >
        <div class="container ">
          <?php 
            ////////////////////////COUNT OF USERS, CUSTOMERS, EVENT MANAGERS and EVENTS //////////////////////
            include 'counter.php';
            $customer_count = counter("SELECT COUNT(*) FROM users WHERE user_type = 'c'");
            $manager_count = counter("SELECT COUNT(*) FROM event_manager_details");
            $events_count = counter("SELECT COUNT(*) FROM event_details");
            $total_users_count = counter("SELECT COUNT(*) FROM users");
            ///////////////////////////////////////////////////////////////////////////////////////////////////
            
            $types_arr = ['Total Customers','Total Managers','Total Events','Total Users'];
            $counts = [$customer_count,$manager_count,$events_count,$total_users_count];
          ?>

          <?php
            for ($i=0; $i < 1 ; $i++) { 
              echo '<div class="row mt-3 " >';
              for($j=0;$j< count($types_arr);$j++) {
                echo '<div class="col-sm-12 col-md-5 col-xl-5 mx-auto my-3">
                  <div class="card disp_card text-center">
                    <div class="card-header">'.$types_arr[$j].'</div>
                    <div class="card-body pt-5"><span class="h1">'.$counts[$j].'</span></div>
                  </div>
                </div>';
              }
              echo '</div>';
            }
          ?>

          <?php
              //////////////////////////////////////For Chart///////////////////////////////////
              $query = "select count(*) from users";
          ?>
        </div>
        <canvas id="myChart"></canvas>
        <canvas id="myChart2"></canvas>
      </div>
    </div>
        
  </div>
</body>

</html>