<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "event_management";
$conn = new PDO("mysql:host=$servername;dbname=$db_name", $username, $password);

    $customer = "SELECT * FROM users WHERE user_type = 'c'";
    $manager = "SELECT * FROM event_manager_details";
    $events = "SELECT * FROM event_details";
    $total_users = "SELECT * FROM users";
    
    $stmt1 = $conn->query($customer);
    echo "<table border='1'>";
    while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr> <td>" . $row['sr_no'] . "</td> <td>" . $row['name'] . "</td> <td>" . $row['email_id'] . "</td> </tr>";
    }
  echo "</table>";
    mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Table</title>
</head>
<body>  
  
</body>
</html>