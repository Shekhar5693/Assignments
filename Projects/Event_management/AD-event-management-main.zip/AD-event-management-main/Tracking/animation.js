function animation(elem_one, elem_two) {
  let elem = document.getElementById(elem_one);
  let width = 5;
  let id = setInterval(frame, 3);

  function frame() {
    if (width >= 100) {
      clearInterval(id);
    } else {
      width++;
      elem.style.width = width + "%";
    }
  }

  setTimeout(() => {
    let elem = document.getElementById(elem_two);
    let width = 1;
    let height = 1;
    let id = setInterval(frame, 3);

    function frame() {
      if (width >= 100) {
        clearInterval(id);
      } else {
        width += 25;
        height += 25;
        elem.style.width = width + "%";
        elem.style.height = height + "%";
      }
    }
  }, 500);
  clearTimeout();
  return true;
}
