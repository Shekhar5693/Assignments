<?php
if ($row['is_location_dec'] == '1') {
  echo '<script>
  animation("bar1", "dot2")
</script>';
  if ($row['is_started'] == '1') {
    echo '<script>
  setTimeout(() => {
    animation("bar2", "dot3");
  }, 600);
</script>';
    if ($row['is_decorated'] == '1') {
      echo '<script>
  setTimeout(() => {
    animation("bar3", "dot4");
  }, 1200);
</script>';
      if ($row['is_finished'] == '1') {
        echo '<script>
  setTimeout(() => {
    animation("bar4", "dot5");
  }, 1800);
</script>';
      }
    }
  }
}
