<?php
require_once 'pdo.php';
$uname = $_POST['name'];
$sql = "Select * from event_status where event_id in ( select event_id from event_details where username = " . "'$uname')";
echo $sql;
$stmt = $pdo->prepare($sql);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row['is_finished'] == '1') {
  $sql = "update event_status set is_finished = 0 where event_id in ( select event_id from event_details where username = " . "'$uname')";
  $stmt = $pdo->prepare($sql);
  $stmt->execute();
} else {
  if ($row['is_decorated'] == '1') {
    $sql = "update event_status set is_decorated = 0 where event_id in ( select event_id from event_details where username = " . "'$uname')";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
  } else {
    if ($row['is_started'] == '1') {
      $sql = "update event_status set is_started = 0 where event_id in ( select event_id from event_details where username = " . "'$uname')";
      $stmt = $pdo->prepare($sql);
      $stmt->execute();
    } else {
      if ($row['is_location_dec'] == '1') {
        $sql = "update event_status set is_location_dec = 0 where event_id in ( select event_id from event_details where username = " . "'$uname')";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        echo '
          <script>
            document.getElementById("re").type = "Hidden";
          </script>
          ';
      }
    }
  }
}
