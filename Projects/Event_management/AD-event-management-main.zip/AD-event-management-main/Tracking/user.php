<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tracking</title>
</head>

<body>
  <style>
    <?php include 'font.css'; ?>
  </style>
  <div>
    <?php include 'body.html'; ?>
  </div>
  <script>
    <?php include 'animation.js'; ?>
  </script>
  <br>
  <?php
  require_once "pdo.php";
  $sql = "Select * from event_status where event_id in ( select event_id from event_details where username = :user)";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array(':user' => $_SESSION['username']));
  $row = $stmt->fetch(PDO::FETCH_ASSOC);

  include "animation.php";

  if ($row['is_completed'] == '1') {
    print <<<END
      <p>
        <button id ="pay" stype="button">Proceed To Payment</button>
      </p>
    END;
  }
  ?>
</body>

</html>