$(document).ready(function () {
  console.log("Jquery Works Fine!!");
  AOS.init();

  $.ajax({
    url: "http://127.0.0.1:8000/admin-charts/data.php",
    method: "GET",
    dataType: 'JSON',
    success: function (data) {
    //   console.log("COUNT : "+data['DS1'][0].count);
    //   console.log("MONTH : ",data['DS1'][0].month);
      
      var months = [];
      var total_users = [];
      var paymonth = [];
      var revenue = [];
      
      for (var i=0; i<data['DS1'].length; i++) {  //putting data for chart
        months.push(data['DS1'][i].month);
        total_users.push(data['DS1'][i].count);
    }
    
      
      for (var i=0; i<data['DS2'].length; i++) {
        paymonth.push(data['DS2'][i].payment_month);
        revenue.push(data['DS2'][i].revenue);
      }

      console.log("Months : "+ months);
      console.log("Count : "+ total_users);
      console.log("Payment Months : "+ paymonth);
      console.log("Revenue : "+ revenue);
      

      if(document.getElementById('TotalUsers')) {
          var ctx = document.getElementById('TotalUsers').getContext('2d');
          
        var chart = new Chart(ctx, {
            // The type of chart we want to create
            type: 'line',

            // The data for our dataset
            data: {
            labels: months,
            datasets: [{
                label: 'Our Reach in 2021',
                backgroundColor: 'rgba(255, 99, 132,0.1)',
                borderColor: 'rgb(255, 199, 132)',
                data: total_users,
            }]
            },

            // Configuration options go here
            options: {
            scales: {
                yAxes: [{
                ticks: {
                    beginAtZero: true
                }
                }]
            }
            }
        });
      }
      if(document.getElementById('TotalRevenue')) {
          var ctx2 = document.getElementById('TotalRevenue').getContext('2d');
          
      var chart2 = new Chart(ctx2, {
        // The type of chart we want to create
        type: 'line',

        // The data for our dataset
        data: {
          labels: paymonth,
          datasets: [{
            label: 'Revenue',
            backgroundColor: 'rgba(78, 133, 132,0.1)',
            borderColor: 'rgb(78, 133, 132)',
            data: revenue,
          }]
        },

        // Configuration options go here
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });
      }
      


    },
    error: function (data) {
      console.log("Error : ");
      console.log(data);
    }
  });
  //Enter your js code here if necessary.
  // function drawGraph(id,data) {
    
  // }
});