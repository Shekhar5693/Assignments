<?php
require_once "conn.php";
// session_start();
// if ( ! isset($_SESSION['name']) ) {
//     die('<h1><a href="login.php">Please log in</a></h1>');
// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    require_once "includes/header.php";
    ?>
    <title>Charts</title>
    <script type="application/javascript" src="/admin-panel-arslaan/vendor/chart.js/Chart.min.js"> </script>
    <script type="application/javascript" src="/admin-panel-arslaan/vendor/jquery/jquery.min.js"></script>
    <script type="application/javascript" src="/admin-panel-arslaan/js/mychart.js"></script>
    <script>
        // $(document).ready(function () {
        //     var ctx = document.getElementById('mychart');
            
        // });
    </script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php require_once "includes/navbar.php"; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->

                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                    </div>
                    <!-- Content Row -->


                    <div class="container-fluid " >
                        <div class="row ">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                    <h4 class="card-title">The Yearly Users Reach</h4>
                                    <!-- <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6> -->
                                    <p class="card-text">Given below is the graphical representation of our total users</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 table-responsive" style="position:relative;">
                            <canvas id="mychart" style="height:60vh;width:80%;"></canvas>
                            </div>
                        </div>
                    </div>

                    <div class="container-fluid " >
                        <div class="row ">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                    <h4 class="card-title">The Yearly Users Reach</h4>
                                    <!-- <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6> -->
                                    <p class="card-text">Given below is the graphical representation of our total users</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 table-responsive" style="position:relative;">
                            <canvas id="mychart2" style="height:60vh;width:80%;"></canvas>
                            </div>
                        </div>
                    </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <?php
            require_once "includes/footer.php";
            require_once "includes/scripts.php";
            ?>

            <script>
                $(document).ready(function() {
                    $(".nav-item:first").addClass("active");
                    $("#administrator").addClass("collapsed");
                    $("#event-managers").addClass("collapsed");
                });
            </script>
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


</body>

</html>