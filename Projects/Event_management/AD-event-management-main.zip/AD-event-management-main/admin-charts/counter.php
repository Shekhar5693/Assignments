<?php 
function counter($myquery) {
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $db_name = "event_management";
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$db_name", $username, $password);
        $stmt = $conn->query($myquery);
        $r_count = $stmt->fetchColumn();
        // echo $r_count;
        return $r_count;
    }
    catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        $conn = null;
    }
}
// counter("SELECT COUNT(*) FROM student_info");
?>