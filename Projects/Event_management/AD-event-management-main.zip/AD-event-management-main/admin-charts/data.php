<?php
  include "dbconnect.php";
    
  $data = array();
    $stmt = $conn->query("SELECT DATE_FORMAT(timestamp,'%M') as months, count(*) as counts FROM users group by months order by timestamp");
    $stmt2 = $conn->query("SELECT DATE_FORMAT( FROM_UNIXTIME( unix_timestamp(payment_date) ),'%M') as payment_month, sum(amount) as revenue FROM membership group by payment_month order by payment_date");

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $data['DS1'][] = array('month' => $row['months'],'count' => $row['counts']);
    }

    while ($row = $stmt2->fetch(PDO::FETCH_ASSOC)) {
      $data['DS2'][] = array('payment_month' => $row['payment_month'],'revenue' => $row['revenue']);
    } 

    $data = json_encode($data);
    print_r($data);
?>