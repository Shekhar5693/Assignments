<?php 
// include 'navbar.php';
// include 'index.html';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin DashBoard</title>
  <link rel="stylesheet" href="../../static/Plugins/BootStrap/bootstrap.min.css">
  <link rel="stylesheet" href="../../static/AdminDashBoard/index.css">
  <link rel="stylesheet" href="../../static/Plugins/AOS/aos.css">
  <link rel="stylesheet" href="../../static/AdminDashboard/base.css">
  <script src="../../static/Plugins/Jquery/jquery.min.js"></script>
  <script src="../../static/Plugins/BootStrap/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
  <script src="../../static/Plugins/AOS/aos.js"></script>
</head>

<body>
  <!-- <div class="container-fluid" data-aos="fade-down">
    <div class="row">
      <div class="col-2 mt-5" style="position: fixed;" data-aos="fade-up" data-aos-delay="150"> 
        <div class="accordion" id="accordionExample">
          <div class="card">
            <div class="card-header" id="headingOne">
              <h2 class="mb-0 text-center">
                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  Event Managers
                </button>
              </h2>
            </div>
        
            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
              <div class="card-body text-center">
                <a href="">Manager Details </a> <hr>
                <a href="">Manager Progress </a>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header" id="headingTwo">
              <h2 class="mb-0 text-center">
                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  Customers
                </button>
              </h2>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
              <div class="card-body text-center">
                <a href="">Customer Details</a> <hr>
                <a href="">Customer Progress </a>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header" id="headingThree">
              <h2 class="mb-0 text-center">
                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                  Admins
                </button>
              </h2>
            </div>
            <div id="collapseThree" class="collapse show" aria-labelledby="headingThree" data-parent="#accordionExample">
              <div class="card-body text-center">
                <a href="">Total Revenue</a> <hr>
                <a href="">Total User Count </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-10 ml-auto">
        
      </div>
    </div>
        
  </div> -->

    <?php
        function TotalUsers() {
    ?>
    <canvas id='TotalUsers'></canvas>
    <?php
        }
        function TotalRevenue() {
    ?>
    <canvas id='TotalRevenue'></canvas>
    <?php
        }
        // TotalUsers();
        // TotalRevenue();
    ?>
    
    <script src="../admin-charts/app.js"></script>
</body>

</html>