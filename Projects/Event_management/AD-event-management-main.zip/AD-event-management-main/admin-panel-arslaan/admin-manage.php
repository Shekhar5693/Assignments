<?php
require_once "conn.php";
session_start();
if ( ! isset($_SESSION['name']) ) {
    die('<h1><a href="login.php">Please log in</a></h1>');
}

use PHPMailer\PHPMailer\PHPMailer;

if ( isset($_POST["approve"]) && isset($_POST["username"]) ) {
    $stmt = $pdo->prepare('UPDATE users SET admin_status=1 WHERE username="'.$_POST["username"].'"');
    
    if ( $stmt->execute() ) {

        $stmt=$pdo->query('SELECT * from users WHERE username="'.$_POST["username"].'"');
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $uname = $row['username'];
        $name = $row['name'];
        $email = $row['email'];
        $mobile = $row['mobile_no'];

        require_once "PHPMailer/PHPMailer.php";
        require_once "PHPMailer/SMTP.php";
        require_once "PHPMailer/Exception.php";

        $mail = new PHPMailer();

        //smtp settings
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Username = "thearsrock1234@gmail.com";
        $mail->Password = '';
        $mail->Port = 465;
        $mail->SMTPSecure = "ssl";

        //email settings
        $mail->isHTML(true);
        $mail->setFrom('thearsrock1234@gmail.com', 'Event Management');
        $mail->addAddress($email);
        $mail->Subject = ("Profile Approval - Event Management");
        $mail->Body = "Congratulations! We would like to let you know, that your admin profile (<b>".$uname."</b>) is approved and active.<br><br>Thank you for registering with us.<br>Event-Management.com";
        // $mail->send();

        $_SESSION["success"] = "User approved Successfully...";
        header('Location: admin-manage.php');
        return;
    }
}

if ( isset($_POST["deny"]) && isset($_POST["username"]) ) {
    $stmt = $pdo->prepare('DELETE FROM users WHERE username="'.$_POST["username"].'"');

    if ($stmt->execute()) {
        $_SESSION["success"] = "User Removed Successfully...";
        header('Location: admin-manage.php');
        return;
    }
}

if ( isset($_POST['username']) && isset($_POST['name']) && isset($_POST['email']) && isset($_POST['pass']) && isset($_POST['mobile']) ) {
    
    //Data validation for adding
    if ( strlen($_POST['mobile'])>10 || strlen($_POST['mobile'])<10 ) {
        $_SESSION["error"] = "Invaid mobile number!";
        header('Location: admin-manage.php');
        return;
    }
    
    // image execution
    $folder ="uploads/";
    $image = $_FILES['image']['name'];
    $img_type = $_FILES['image']['type'];
    $img_size = $_FILES['image']['size'];
    $temp = $_FILES['image']['tmp_name'];
    
    $path = $folder.$image ;
    
    // if image is uploaded then validate
    if($image) {

        //file type checking
        if($img_type=="image/jpeg" || $img_type=="image/jpg" || $img_type=="image/png") {
            
            // image size check
            if ($img_size < 5000000) {
                move_uploaded_file( $temp, $path);
            }
            else {
                $_SESSION["error"] = "image size exceeds 5MB";
                header('Location: admin-manage.php');
                return;
            }
        }
        else {
            $_SESSION["error"] = "Only jpeg, jpg & png are allowed";
            header('Location: admin-manage.php');
            return;
        }
    }
    
    // encrypting password
    $salt = 'XyZzy12*_';
    $pass = hash('md5', $salt.$_POST['pass']);

    // inserting data
    $stmt = $pdo->prepare("INSERT INTO `users`(`username`, `name`, `email`, `password`, `dp`, `mobile_no`, `user_type`, `admin_status`) VALUES (:username, :name, :email, :pass, :dp, :mobile_no, :user_type, :admin_status)");
    $stmt->execute(array(
        ':username' => $_POST["username"],
        ':name' => $_POST["name"],
        ':email' => $_POST["email"],
        ':pass' => $pass,
        ':dp' => $image,
        ':mobile_no' => $_POST["mobile"],
        ':user_type' => "admin",
        ':admin_status' => 1
    ));
    
    $_SESSION["success"] = "User Registered Successfully...";
    header('Location: admin-manage.php');
    return;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        require_once "includes/header.php";
    ?>

    <title>
        <?php echo strtoupper($_SESSION['name']) ?> - Profile
    </title>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php require_once "includes/navbar.php"; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php require_once "includes/topNav.php" ?>
                <!-- End of Topbar -->

                <div class="container">

                    <?php
                        if (isset($_SESSION["success"]))   {
                            echo '<div class="col-12 mt-2">';
                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                            echo "<strong>";
                            echo htmlentities($_SESSION["success"]);
                            unset($_SESSION["success"]);
                            echo "</strong>";
                            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>';
                            echo '</div></div>';
                        }
                        if (isset($_SESSION["error"]))   {
                            echo '<div class="col-12 mt-2">';
                            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                            echo "<strong>";
                            echo htmlentities($_SESSION["error"]);
                            unset($_SESSION["error"]);
                            echo "</strong>";
                            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>';
                            echo '</div></div>';
                        }
                    ?>

                    <div class="row mt-3 mb-4">
                        <div class="col-12">
                        
                            <!-- Requests Card -->
                            <div class="card shadow">
                                <div class="card-header">
                                    <h5 class="m-0 font-weight-bold text-primary">
                                        New Requests&emsp;
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addAdmin">
                                        Add admin
                                        </button>
                                    </h5>

                                    <!--Add admin Modal -->
                                    <div class="modal fade" id="addAdmin" tabindex="-1" aria-labelledby="addAdminLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addAdminLabel">Add a new admin</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="POST" class="user" enctype="multipart/form-data">
                                                        <div class="form-group row">
                                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                                <input type="text" class="form-control form-control-user" name="username" id="" placeholder="Username*" required>
                                                            </div>
                                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                                <input type="text" class="form-control form-control-user" name="name" id="" placeholder="Full Name*" required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <input type="email" class="form-control form-control-user" name="email" id="" placeholder="Email Address*"  required>
                                                        </div>
                                                        <div class="form-group row">
                                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                                <input type="password" class="form-control form-control-user" name="pass" id="" placeholder="Password*"  required>
                                                            </div>
                                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                                <input type="number" class="form-control form-control-user" name="mobile" id="" placeholder="Mobile Number*" required>
                                                            </div>
                                                            <div class="col-11 mt-3 ml-3 text-center">
                                                                <input type="file" class="custom-file-input form-control-user" name="image" id="" name="filename">
                                                                <label class="custom-file-label" for="customFile">Profile Picture (optional) &lt; 5MB</label>
                                                            </div>
                                                        </div>

                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">
                                                                Register Account
                                                            </button>
                                                        </div>
                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- END of Modal -->

                                </div>

                                <div class="card-body">
                                    <!-- Requests Table -->
                                    <div class="table-responsive m-2">
                                        <table class="table table-striped" id="adminRequestTable">
                                            <thead class="text-dark">
                                                <tr>
                                                <th scope="col">Username</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Mobile</th>
                                                <th scope="col">Image</th>
                                                <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                                $stmt=$pdo->query("SELECT * from users WHERE admin_status=0 AND user_type='admin'");
                                                if ($stmt->rowCount() > 0 && isset($_SESSION['name']) ) {
                                                    while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
                                                        echo '<tr><th scope="row">';
                                                        echo(htmlentities($row['username']));
                                                        echo("</th><td>");
                                                        echo(htmlentities($row['name']));
                                                        echo("</td><td>");
                                                        echo(htmlentities($row['email']));
                                                        echo("</td><td>");
                                                        echo(htmlentities($row['mobile_no']));
                                                        echo("</td><td>");
                                                        echo( ' ' );
                                                        ?>
                                                        <a class="dp" href="#imagemodal" data-toggle="modal" data-target="#imagemodal">
                                                            <button class="btn btn-outline-warning btn-sm" value="uploads/<?php echo $row['dp'] ?>">image</button>
                                                        </a>
                                                        <?php
                                                        echo("</td><td>");
                                                        echo( "<form method='POST'>
                                                                <input type='hidden' name='username' value=".$row['username']." />
                                                                <input type='submit' name='approve' value='Approve' class='btn btn-success btn-sm' />
                                                                <input type='submit' name='deny' value='Deny' />
                                                            </form>" );
                                                        echo("</td></tr>");
                                                    }
                                                } else {
                                                    echo "No new requests";
                                                }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- END of Request Table -->
                                </div>

                            </div>
                            <!-- END of Requests Card -->

                        </div> 
                    </div>
                    
                    <div class="row mt-3 mb-2">
                        <div class="col-12">

                            <!-- Admin List Card-->
                            <div class="card shadow">
                                <div class="card-header">
                                    <h5 class="m-0 font-weight-bold text-primary">
                                        Current Administrators
                                    </h5>
                                </div>

                                <!-- Current Admins List Table -->
                                <div class="card-body">
                                    <div class="table-responsive m-2">
                                        <table class="table table-striped" id="AdminListTable">
                                            <thead class="text-dark">
                                                <tr>
                                                <th scope="col">Username</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Mobile</th>
                                                <th scope="col">Image</th>
                                                <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                                $stmt=$pdo->query("SELECT * from users WHERE admin_status=1  AND user_type='admin'");
                                                if ($stmt->rowCount() > 0 && isset($_SESSION['name']) ) {
                                                    while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
                                                        echo '<tr><th scope="row">';
                                                        echo(htmlentities($row['username']));
                                                        echo("</th><td>");
                                                        echo(htmlentities($row['name']));
                                                        echo("</td><td>");
                                                        echo(htmlentities($row['email']));
                                                        echo("</td><td>");
                                                        echo(htmlentities($row['mobile_no']));
                                                        echo("</td><td>");
                                                        echo( ' ' );
                                                        ?>
                                                        <a class="dp" href="#imagemodal" data-toggle="modal" data-target="#imagemodal">
                                                            <button class="btn btn-outline-warning btn-sm" value="uploads/<?php echo $row['dp'] ?>">image</button>
                                                        </a>
                                                        <?php
                                                        echo("</td><td>");
                                                        echo( "<form method='POST'>
                                                                <input type='hidden' name='username' value=".$row['username']." />
                                                                <input type='submit' name='deny' value='Remove' class='btn btn-danger btn-sm' />
                                                            </form>" );
                                                        echo("</td></tr>");
                                                    }
                                                } else {
                                                    echo "No new requests";
                                                }
                                            ?>
                                            <!--Image Modal -->
                                            <div class="modal fade" id="imagemodal" tabindex="-1" aria-labelledby="imageLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <img class="modal-img" alt=" no profile picture">
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END of Image Modal -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- END of Current Admins List Table -->

                            </div>
                            <!-- END of Admin List Card-->

                        </div> 
                    </div>

                    
                </div>

            </div>
            <!-- End of Main Content -->

            <?php
            require_once "includes/footer.php";
            require_once "includes/scripts.php";
            ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

        <script>
            // active tab
            $(document).ready(function(){
                $(".nav-item:nth-of-type(2)").addClass("active");
                $("#admin-manage").addClass("active");
                $("#event-managers").addClass("collapsed");
                $("#collapseTwo").addClass("show");
                
                // initializing table css
                $('#adminRequestTable').DataTable();
                $('#AdminListTable').DataTable();

                // File upload script
                $(".custom-file-input").on("change", function() {
                    var fileName = $(this).val().split("\\").pop();
                    $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
                });

                // image modal
                $(function(){
                    $(".dp button").on("click",function(){
                        var src = $(this).attr("value");
                        // var src = $(this).attr("src");
                        $(".modal-img").prop("src",src);
                    })
                })

            });

        </script>

    </body>
</html>



