<?php
require_once "conn.php";
session_start();
if ( ! isset($_SESSION['name']) ) {
    die('<h1><a href="login.php">Please log in</a></h1>');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        require_once "includes/header.php";
    ?>
    <title>
        <?php echo strtoupper($_SESSION['name']) ?> - Profile
    </title>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php require_once "includes/navbar.php"; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php require_once "includes/topNav.php" ?>
                <!-- End of Topbar -->
                <?php require_once "includes/topNav.php" ?>
                <?php require_once "../admin-charts/index.php" ?>
                <?php TotalUsers(); ?>
                <?php TotalRevenue(); ?>
            </div>
            <!-- End of Main Content -->

            <?php
            require_once "includes/footer.php";
            require_once "includes/scripts.php";
            ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    </body>
</html>



