<?php
require_once "conn.php";
session_start();
if ( ! isset($_SESSION['name']) ) {
    die('<h1><a href="login.php">Please log in</a></h1>');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        require_once "includes/header.php";
    ?>
    <title>Admin Dashboard</title>
</head>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <?php require_once "includes/navbar.php"; ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php require_once "includes/topNav.php" ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                            class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                </div>
                <?php
                    if (isset($_SESSION["success"]))   {
                        echo '<div class="col-12 col-lg-6 mt-2">';
                        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                        echo "<strong>";
                        echo htmlentities($_SESSION["success"]);
                        unset($_SESSION["success"]);
                        echo "</strong>";
                        echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>';
                        echo '</div></div>';
                    }
                    if (isset($_SESSION["error"]))   {
                        echo '<div class="col-12 col-lg-6 mt-2">';
                        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                        echo "<strong>";
                        echo htmlentities($_SESSION["error"]);
                        unset($_SESSION["error"]);
                        echo "</strong>";
                        echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>';
                        echo '</div></div>';
                    }
                ?>

                <!-- Content Row -->
                <div class="row">

                    <!-- Earnings (Monthly) Card Example -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Ongoing Events</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php
                                            $stmt=$pdo->query("SELECT COUNT(*) from event_details ");
                                            $stmt->execute();
                                            print_r( $stmt->fetchColumn() );
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Earnings (Monthly) Card Example -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Completed Events</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php
                                                $stmt=$pdo->query("SELECT COUNT(*) from event_status WHERE is_completed=1");
                                                $stmt->execute();
                                                print_r( $stmt->fetchColumn() );
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Earnings (Monthly) Card Example -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Profit
                                        </div>
                                        <div class="row no-gutters align-items-center">
                                            <div class="col-auto">
                                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                <?php
                                                $stmt=$pdo->query("SELECT sum(amount) from membership");
                                                $stmt->execute();
                                                print_r( $stmt->fetchColumn() );
                                            ?>
                                                </div>
                                            </div>
                                            <!-- <div class="col">
                                                <div class="progress progress-sm mr-2">
                                                    <div class="progress-bar bg-info" role="progressbar"
                                                        style="width: 50%" aria-valuenow="50" aria-valuemin="0"
                                                        aria-valuemax="100"></div>
                                                </div>
                                            </div> -->
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pending Requests Card Example -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            
                            <a href="admin-manage.php">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Admin Requests</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php
                                                $stmt=$pdo->query("SELECT COUNT(username) from users WHERE admin_status=0");
                                                $stmt->execute();
                                                print_r( $stmt->fetchColumn() );
                                        ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-comments fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                            </a>

                        </div>
                    </div>
                </div>
                
                <div class="container">
                    <?php require_once "../admin-charts/index.php"; ?>
                    <?php TotalUsers(); ?>
                </div>
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <?php
        require_once "includes/footer.php";
        require_once "includes/scripts.php";
        ?>

        <script>
            $(document).ready(function(){
                $(".nav-item:first").addClass("active");
                $("#administrator").addClass("collapsed");
                $("#event-managers").addClass("collapsed");
            });
        </script>
    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->


    </body>
</html>



