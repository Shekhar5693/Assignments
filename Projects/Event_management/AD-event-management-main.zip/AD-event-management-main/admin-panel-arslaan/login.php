<?php
require_once "conn.php";
session_start();

$salt = 'XyZzy12*_';

if ( isset($_POST['user']) && isset($_POST['pass']) ) {

    unset($_SESSION['name']);
    unset($_SESSION['uname']);
    unset($_SESSION['email']);
    unset($_SESSION['mobile']);
    unset($_SESSION['dp']);
    unset($_SESSION['userType']);
	
	$pass = hash('md5', $salt.$_POST['pass']);

	if ($stmt = $pdo->prepare('SELECT * FROM users WHERE username=:uname AND password=:pw AND admin_status=1')) {
        
        $stmt->execute(array( ':uname'=>$_POST['user'], ':pw'=> $pass ));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
        if ( $row !== false) {
            $_SESSION['name'] = $row['name'];
            $_SESSION['uname'] = $row['username'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['mobile'] = $row['mobile_no'];
            $_SESSION['dp'] = $row['dp'];
            $_SESSION['userType'] = $row['user_type'];
    
            //uppercase username strtoupper
            $_SESSION['success'] = "Logged in as ".strtoupper($_SESSION['name']);
            header('Location: index.php');
            return;
        }
        else {
            $_SESSION['error'] = "Incorrect Credentials";
            header('Location: login.php');
            return;
        }
    }
    else {
        $_SESSION['error'] = "User not approved...";
        header('Location: login.php');
        return;
    }

}
//model is over, now its output time
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <?php
        require_once "includes/header.php";
    ?>
    <title>Admin Login - Event Management</title>

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome Admin!</h1>
                                    </div>
                                    <?php
                                        if (isset($_SESSION["success"]))   {
                                            echo '<div class="col-12 mt-2">';
                                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                                            echo "<strong>";
                                            echo htmlentities($_SESSION["success"]);
                                            unset($_SESSION["success"]);
                                            echo "</strong>";
                                            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>';
                                            echo '</div></div>';
                                        }
                                        if (isset($_SESSION["error"]))   {
                                            echo '<div class="col-12 mt-2">';
                                            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                                            echo "<strong>";
                                            echo htmlentities($_SESSION["error"]);
                                            unset($_SESSION["error"]);
                                            echo "</strong>";
                                            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>';
                                            echo '</div></div>';
                                        }
                                    ?>
                                    <form method="POST" class="user">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="user"
                                                id="exampleInputEmail" aria-describedby="emailHelp"
                                                placeholder="Username" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" name="pass"
                                                id="exampleInputPassword" placeholder="Password" required>
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <input type="checkbox" class="custom-control-input" id="customCheck">
                                                <label class="custom-control-label" for="customCheck">Remember
                                                    Me</label>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-user btn-block">
                                            Login
                                        </button>
                                        <!-- <hr>
                                        <a href="index.php" class="btn btn-google btn-user btn-block">
                                            <i class="fab fa-google fa-fw"></i> Login with Google
                                        </a>
                                        <a href="index.php" class="btn btn-facebook btn-user btn-block">
                                            <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                                        </a> -->
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="forgot-password.php">Forgot Password?</a>
                                    </div>
                                    <div class="text-center">
                                        <a class="small" href="register.php">Create an Account!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <?php
        require_once "includes/scripts.php";
    ?>

</body>

</html>