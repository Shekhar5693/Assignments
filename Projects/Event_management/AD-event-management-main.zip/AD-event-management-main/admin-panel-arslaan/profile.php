<?php
require_once "conn.php";
session_start();
if ( ! isset($_SESSION['name']) ) {
    die('<h1><a href="login.php">Please log in</a></h1>');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        require_once "includes/header.php";
    ?>
    <title>
        <?php echo strtoupper($_SESSION['name']) ?> - Profile
    </title>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php require_once "includes/navbar.php"; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php require_once "includes/topNav.php" ?>
                <!-- End of Topbar -->

                <!-- Details Card -->
                
                <div class="row">
                    <div class="col-lg-6">
                        <img class="m-5" src="uploads/<?php echo $_SESSION["dp"] ?>" alt="" height="200">
                    </div>
                    <div class="col-lg-6">
                        <div class="card shadow mr-5 mt-5">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">My Details</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-4">
                                        <h5>Username:&emsp;</h5>
                                        <h5>Name:&emsp;</h5>
                                        <h5>Email:&emsp;</h5>
                                        <h5>Mobile:&emsp;</h5>
                                        <!-- <h5>Password:&emsp;</h5> -->
                                    </div>
                                    <div class="col-8">
                                        <h5><?php echo $_SESSION["uname"] ?> </h5>
                                        <h5><?php echo strtoupper($_SESSION["name"]) ?> </h5>
                                        <h5><?php echo $_SESSION["email"] ?> </h5>
                                        <h5><?php echo $_SESSION["mobile"] ?> </h5>
                                    </div>
                                </div>
                                <div class="row">
                                    <a href="forgot-password.php" class="btn btn-primary btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-flag"></i>
                                        </span>
                                        <span class="text">Change Password</span>
                                    </a>

                                </div>
                            </div>
                        </div>
                        <div class="mt-5">
                        </div>
                    </div>
                </div>

            </div>
            <!-- End of Main Content -->

            <?php
            require_once "includes/footer.php";
            require_once "includes/scripts.php";
            ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    </body>
</html>



