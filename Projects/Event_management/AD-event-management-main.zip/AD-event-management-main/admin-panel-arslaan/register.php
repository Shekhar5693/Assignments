<?php
require_once "conn.php";
session_start();

if ( isset($_POST['username']) && isset($_POST['name']) && isset($_POST['email']) && isset($_POST['pass']) && isset($_POST['mobile']) ) {
    
    //Data validation for adding
    if ( strlen($_POST['mobile'])>10 || strlen($_POST['mobile'])<10 ) {
        $_SESSION["error"] = "Invaid mobile number!";
        header('Location: register.php');
        return;
    }
    
    // image execution
    $folder ="uploads/";
    $image = $_FILES['image']['name'];
    $img_type = $_FILES['image']['type'];
    $img_size = $_FILES['image']['size'];
    $temp = $_FILES['image']['tmp_name'];
    
    $path = $folder.$image ;
    
    // if image is uploaded then validate
    if($image) {

        //file type checking
        if($img_type=="image/jpeg" || $img_type=="image/jpg" || $img_type=="image/png") {
            
            // image size check
            if ($img_size < 5000000) {
                move_uploaded_file( $temp, $path);
            }
            else {
                $_SESSION["error"] = "image size exceeds 5MB";
                header('Location: register.php');
                return;
            }
        }
        else {
            $_SESSION["error"] = "Only jpeg, jpg & png are allowed";
            header('Location: register.php');
            return;
        }
    }
    
    // encrypting password
    $salt = 'XyZzy12*_';
    $pass = hash('md5', $salt.$_POST['pass']);

    // inserting data
    $stmt = $pdo->prepare("INSERT INTO `users`(`username`, `name`, `email`, `password`, `dp`, `mobile_no`, `user_type`, `admin_status`) VALUES (:username, :name, :email, :pass, :dp, :mobile_no, :user_type, :admin_status)");
    $stmt->execute(array(
        ':username' => $_POST["username"],
        ':name' => $_POST["name"],
        ':email' => $_POST["email"],
        ':pass' => $pass,
        ':dp' => $image,
        ':mobile_no' => $_POST["mobile"],
        ':user_type' => "admin",
        ':admin_status' => 0
    ));
    
    $_SESSION["success"] = "User sent for approval...";
    header('Location: register.php');
    return;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <?php
        require_once "includes/header.php";
    ?>
    <title>Admin Sign Up</title>

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create Admin Account!</h1>
                            </div>
                            <?php
                                if (isset($_SESSION["success"]))   {
                                    echo '<div class="col-12 mt-2">';
                                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                                    echo "<strong>";
                                    echo htmlentities($_SESSION["success"]);
                                    unset($_SESSION["success"]);
                                    echo "</strong>";
                                    echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>';
                                    echo '</div></div>';
                                }
                                if (isset($_SESSION["error"]))   {
                                    echo '<div class="col-12 mt-2">';
                                    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                                    echo "<strong>";
                                    echo htmlentities($_SESSION["error"]);
                                    unset($_SESSION["error"]);
                                    echo "</strong>";
                                    echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>';
                                    echo '</div></div>';
                                }
                            ?>
                            <form method="POST" class="user" enctype="multipart/form-data">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" name="username" id="" placeholder="Username*" required>
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" name="name" id="" placeholder="Full Name*" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control form-control-user" name="email" id="" placeholder="Email Address*"  required>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="password" class="form-control form-control-user" name="pass" id="" placeholder="Password*"  required>
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="number" class="form-control form-control-user" name="mobile" id="" placeholder="Mobile Number*" required>
                                    </div>
                                    <div class="col-11 mt-3 ml-3 text-center">
                                        <input type="file" class="custom-file-input form-control-user" name="image" id="" name="filename">
                                        <label class="custom-file-label" for="customFile">Profile Picture (optional) &lt; 5MB</label>
                                    </div>
                                    <!-- <div class="col-sm-6 mb-3 mb-sm-0 mt-3">
                                        <label for="dp">&nbsp;Profile Picture</label>
                                        <input type="file" class="form-control-sm" id="dp" placeholder="file">
                                    </div> -->
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block">
                                    Register Account
                                </button>
                                <!-- <hr>
                                <a href="index.php" class="btn btn-google btn-user btn-block">
                                    <i class="fab fa-google fa-fw"></i> Register with Google
                                </a>
                                <a href="index.php" class="btn btn-facebook btn-user btn-block">
                                    <i class="fab fa-facebook-f fa-fw"></i> Register with Facebook
                                </a> -->
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="forgot-password.php">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="login.php">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <?php
        require_once "includes/scripts.php";
    ?>

    <script>
        // File upload script
        $(".custom-file-input").on("change", function() {
            var fileName = $(this).val().split("\\").pop();
            $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
        });
    </script>

</body>

</html>