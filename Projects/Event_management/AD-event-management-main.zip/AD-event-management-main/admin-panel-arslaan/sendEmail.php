<?php
require_once "conn.php";
session_start();
if ( ! isset($_SESSION['name']) ) {
    die('<h1><a href="login.php">Please log in</a></h1>');
}

use PHPMailer\PHPMailer\PHPMailer;

if ( isset($_POST["toEmail"]) && isset($_POST["subject"]) && isset($_POST["body"]) ) {
    
    $email = $_POST['toEmail'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    
    // $_SESSION['random'] = "<br>".$email." ".$subject." ".$body;

    require_once "PHPMailer/PHPMailer.php";
    require_once "PHPMailer/SMTP.php";
    require_once "PHPMailer/Exception.php";

    $mail = new PHPMailer();

    //smtp settings
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->Username = "thearsrock1234@gmail.com";
    $mail->Password = '';
    $mail->Port = 465;
    $mail->SMTPSecure = "ssl";

    //email settings
    $mail->isHTML(true);
    $mail->setFrom('thearsrock1234@gmail.com', 'Event Management');
    $mail->addAddress($email);
    $mail->Subject = ($subject);
    $mail->Body = $body;
    $mail->send();

    $_SESSION["success"] = "E-mail sent Successfully...";
    header('Location: sendEmail.php');
    return;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        require_once "includes/header.php";
    ?>
    <title>
        <?php echo strtoupper($_SESSION['name']) ?> - Profile
    </title>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php require_once "includes/navbar.php"; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php require_once "includes/topNav.php" ?>
                <!-- End of Topbar -->
                
                <div class="container">

                    <?php
                        if (isset($_SESSION["success"]))   {
                            echo '<div class="col-12 mt-2">';
                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                            echo "<strong>";
                            echo htmlentities($_SESSION["success"]);
                            // echo $_SESSION["random"];
                            unset($_SESSION["success"]);
                            echo "</strong>";
                            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>';
                            echo '</div></div>';
                        }
                        if (isset($_SESSION["error"]))   {
                            echo '<div class="col-12 mt-2">';
                            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                            echo "<strong>";
                            echo htmlentities($_SESSION["error"]);
                            unset($_SESSION["error"]);
                            echo "</strong>";
                            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>';
                            echo '</div></div>';
                        }
                    ?>

                    <div class="row mt-3 mb-4">
                        <div class="col-12">
                        
                            <!-- Requests Card -->
                            <div class="card shadow">
                                <div class="card-header">
                                    <h5 class="m-0 font-weight-bold text-primary">
                                        Compose an Email&emsp;
                                        <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addAdmin">
                                        Add admin
                                        </button> -->
                                    </h5>

                                </div>

                                <div class="card-body">
                                    <!-- Email Form -->
                                    <form method="POST" class="user">
                                        <div class="form-group row">
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <input type="email" class="form-control form-control-user" name="toEmail" id="" placeholder="To*" required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <input type="text" class="form-control form-control-user" name="subject" id="" placeholder="Subject*"  required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <textarea cols="30" rows="10" class="form-control" name="body" placeholder="Message*" required></textarea>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary">
                                            Send Email
                                        </button>
                                    </form>
                                    <!-- END of Email Form -->
                                </div>

                            </div>
                            <!-- END of Requests Card -->

                        </div> 
                    </div>
                    
                </div>

            </div>
            <!-- End of Main Content -->

            <?php
            require_once "includes/footer.php";
            require_once "includes/scripts.php";
            ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->


    </body>
</html>



