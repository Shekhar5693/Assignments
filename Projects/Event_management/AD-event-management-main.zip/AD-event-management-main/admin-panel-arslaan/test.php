<?php
require_once "conn.php";
session_start();
if ( ! isset($_SESSION['name']) ) {
    die('<h1><a href="login.php">Please log in</a></h1>');
}

?>
<img src="uploads/<?php echo $_SESSION["dp"] ?>" alt="">

<h1>
    <?php
    echo $_SESSION['name']."<br>";
    echo $_SESSION['uname']."<br>";
    echo $_SESSION['email']."<br>";
    echo $_SESSION['dp']."<br>";
    echo $_SESSION['userType']."<br>";

    if(isset($_SESSION['mobile']) )
        echo $_SESSION['mobile']."<br>";
    else {
        echo "!no mobile!!!!";
    }
    $is_admin = True;
    ?>

    <script>
    var admin = <?php echo $is_admin ?>;
    alert(admin);
    </script>
</h1>