<?php
$conn = new PDO('mysql:host=localhost;port=3306;dbname=event_management', 'root', '');

// See the "errors" folder for details...
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// if($conn) {
//     echo "connected...";

//     $stmt = $conn->prepare("create database if not exists mytest");
//     $stmt->execute();
//     echo "Created...";
// }