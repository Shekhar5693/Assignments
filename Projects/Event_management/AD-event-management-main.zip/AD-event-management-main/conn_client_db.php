<?php
$host = "localhost";
$user = "root"; //by default root is user name.  
$pwd = "root";   //password is blank by default 
$dbName = "event_management";

try
{
    $pdo = new PDO("mysql:host=$host;dbname=$dbName", $user, $pwd);
    // $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "successfully connected to event_management database\n";
}
catch(PDOException $e)
{
    //echo "Error in connecting to db " . $e->getMessage();
}
?>