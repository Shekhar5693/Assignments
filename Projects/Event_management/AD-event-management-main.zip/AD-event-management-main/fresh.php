
<?php
$connect = new PDO('mysql:host=localhost;port=3306;', 'root', '');

// See the "errors" folder for details...
// $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if($connect) {
    echo "connected...<br>";

    $stmt = $connect->prepare("create database if not exists event_management");
    $stmt->execute();
    
    if($stmt->execute()) {

        $connect = new PDO('mysql:host=localhost;port=3306;dbname=event_management', 'root', '');
        echo "<b>Database EVENT_MANAGEMENT Created Successfully...</b><br><br>";
        
        // $stmt = $connect->prepare("DROP TABLE if exists users");
        // $stmt->execute();
        $sql = "CREATE TABLE if not exists users("
        ."username varchar(30) primary key,"
        ."name varchar(30) not null,"
        ."email varchar(30) not null,"
        ."password varchar(50) not null,"
        ."dp varchar(100) null,"
        ."mobile_no varchar(12) not null,"
        ."user_type varchar(30) not null,"
        ."admin_status bool null"
        ."timestamp date)";
        $stmt = $connect->prepare($sql);
        $stmt->execute();

        if($stmt->execute()) {
            echo "1.users table created...<br>";
            
            $sql = "CREATE TABLE if not exists membership("
            ."username varchar(30) not null,"
            ."payment_date timestamp not null,"
            ."duration datetime not null,"
            ."amount float(10) not null,"
            ."constraint fk_username_membership foreign key (username) references users(username)"
            .")";
            $stmt = $connect->prepare($sql);
            $stmt->execute();
            
            if($stmt->execute())
                echo "2.membership table created...<br>";
        }
        
        if($stmt->execute()) {
            
            $sql = "CREATE TABLE if not exists event_manager_details("
            ."username varchar(30) not null,"
            ."address varchar(500) not null,"
            ."company varchar(30) not null,"
            ."event_types varchar(50) not null,"
            ."photos mediumblob not null,"
            ."area_covered varchar(30) not null,"
            ."bids int(5) not null,"
            ."constraint fk_username_event_manager_details foreign key (username) references users(username)"
            .")";
            $stmt = $connect->prepare($sql);
            $stmt->execute();
            
            if($stmt->execute()) {
                echo "3.event_manager_details table created...<br>";
            }
        }
        
        if($stmt->execute()) {
            
            $sql = "CREATE TABLE if not exists event_details("
            ."event_id int(5) primary key auto_increment,"
            ."username varchar(30) not null,"
            ."location varchar(500) not null,"
            ."attendees int(5) not null,"
            ."budget float(10) not null,"
            ."venue_type varchar(30) not null,"
            ."duration timestamp not null,"
            ."event_type varchar(30) not null,"
            ."description varchar(1000) not null,"
            ."constraint fk_username_event_details foreign key (username) references users(username)"
            .")";
            $stmt = $connect->prepare($sql);
            $stmt->execute();
            
            if($stmt->execute()) {
                echo "4.event_details table created...<br>";
            }
        }
        
        
        if($stmt->execute()) {
            
            $sql = "CREATE TABLE if not exists bid_details("
            ."bid_id int(5) primary key auto_increment,"
            ."username varchar(30) not null,"
            ."event_id int(5) not null,"
            ."amount float(10) not null,"
            ."cover_letter varchar(1000) not null,"
            ."attachments mediumblob null,"
            ."constraint fk_username_bid_details foreign key (username) references users(username),"
            ."constraint fk_event_id_bid_details foreign key (event_id) references event_details(event_id)"
            .")";
            $stmt = $connect->prepare($sql);
            $stmt->execute();
            
            if($stmt->execute()) {
                echo "5.bid_details table created...<br>";
            }
        }
        
        if($stmt->execute()) {
            
            $sql = "CREATE TABLE if not exists guest_list("
            ."event_id int(5) not null,"
            ."event_hash varchar(100) not null,"
            ."guest_name varchar(50) not null,"
            ."guest_status varchar(5) not null,"
            ."guest_count int(5) not null,"
            ."constraint fk_event_id_guest_list foreign key (event_id) references event_details(event_id)"
            .")";
            $stmt = $connect->prepare($sql);
            $stmt->execute();
            
            if($stmt->execute()) {
                echo "6.guest_list table created...<br>";
            }
        }
        
        if($stmt->execute()) {
            
            $sql = "CREATE TABLE if not exists event_status("
            ."event_id int(5) not null,"
            ."is_location_dec boolean not null default 0,"
            ."is_started boolean not null default 0,"
            ."is_decorated boolean not null default 0,"
            ."is_completed boolean not null default 0,"
            ."constraint fk_event_id_event_status foreign key (event_id) references event_details(event_id)"
            .")";
            $stmt = $connect->prepare($sql);
            $stmt->execute();
            
            if($stmt->execute()) {
                echo "7.event_status table created...<br>";
            }
        }
        
        if($stmt->execute()) {
            
            $sql = "CREATE TABLE if not exists chat_details("
            ."username varchar(30) not null,"
            ."time timestamp not null,"
            ."message varchar(1000) not null,"
            ."constraint fk_username_chat_details foreign key (username) references users(username)"
            .")";
            $stmt = $connect->prepare($sql);
            $stmt->execute();
            
            if($stmt->execute()) {
                echo "8.chat_details table created...<br>";
            }
        }
        
        if($stmt->execute()) {
            
            $sql = "CREATE TABLE if not exists reviews("
            ."username varchar(30) not null,"
            ."event_id int(5) not null,"
            ."rating int(2) not null,"
            ."review varchar(500) not null,"
            ."photos mediumblob null,"
            ."constraint fk_username_reviews foreign key (username) references users(username),"
            ."constraint fk_event_id_reviews foreign key (event_id) references event_details(event_id)"
            .")";
            $stmt = $connect->prepare($sql);
            $stmt->execute();
            
            if($stmt->execute()) {
                echo "9.reviews table created...<br>";
            }
        }

    }
    else
        echo "failed :(";
}
