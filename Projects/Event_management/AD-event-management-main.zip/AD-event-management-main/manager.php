<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tracking</title>
</head>

<body>
  <style>
    <?php include 'font.css'; ?>
  </style>
  <?php include 'body.html'; ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
  </script>
  <script>
    <?php include 'animation.js'; ?>

    function update(uname) {
      $.ajax({
        url: 'update_status.php',
        type: 'POST',
        dataType: 'text',
        data: ({
          name: uname
        }),
        success: function(data) {
          location.reload();
        }
      });
    };

    function revert(uname) {
      $.ajax({
        url: 'revert_status.php',
        type: 'POST',
        dataType: 'text',
        data: ({
          name: uname
        }),
        success: function(data) {
          location.reload();
        }
      });
    };
  </script>
  <br>
  <form method="POST">
    <p>Enter Username: <input type="text" name="user"></p>
    <p><input type="submit" value="Submit"></p>
  </form>

  <?php
  require_once "pdo.php";
  $sql = "Select * from event_status where event_id in ( select event_id from event_details where username = :user)";
  $stmt = $pdo->prepare($sql);
  $user_name = $_POST['user'];
  $stmt->execute(array(':user' => $user_name));
  $row = $stmt->fetch(PDO::FETCH_ASSOC);

  include "animation.php";

  if ($row['is_completed'] != '1' && $row['is_location_dec'] != '0') {
    print <<<END
    <p>
      <button id ="up" stype="button" onclick="update('$user_name')">Update Status</button>
      <button id ="re" stype="button" onclick="revert('$user_name')">Revert Status</button>
    </p>
    END;
  } else if ($row['is_completed'] != '1') {
    print <<<END
    <p>
      <button id ="up" stype="button" onclick="update('$user_name')">Update Status</button>
    </p>
    END;
  } else if ($row['is_location_dec'] != '0') {
    print <<<END
    <p>
      <button id ="re" stype="button" onclick="revert('$user_name')">Revert Status</button>
    </p>
    END;
  }
  ?>
</body>

</html>