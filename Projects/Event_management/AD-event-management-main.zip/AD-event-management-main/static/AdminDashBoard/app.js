$(document).ready(function () {
    console.log("Jquery Works Fine!!");

    $.ajax({
        url: "http://127.0.0.1:8000/Templates/AdminDashBoard/index.php",
        method : "GET",
        success: function (response) {
          console.log(response);
          var reach = [];
          var year = [];

          for(var i in response) {
              reach.push("Reach : "+response[i].p)
          }
        },
        error : function(response) {

        }
    });
    AOS.init();
    //Enter your js code here if necessary.
    var ctx = document.getElementById('myChart').getContext('2d');
    var chart = new Chart(ctx, {
      // The type of chart we want to create
      type: 'line',

      // The data for our dataset
      data:{
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [{
          label: 'Our Reach in 2021',
          backgroundColor: 'rgba(255, 99, 132,0.1)',
          borderColor: 'rgb(255, 199, 132)',
          data: [0, 10, 5, 2, 20, 30, 45]
        }]
      },

      // Configuration options go here
      options: {}
    });

    var ctx = document.getElementById('myChart2').getContext('2d');
    var chart = new Chart(ctx, {
      // The type of chart we want to create
      type: 'pie',

      // The data for our dataset
      data:{
        labels: ['January', 'February', 'March', 'April'],
        datasets: [{
          label: 'My First dataset',
          backgroundColor: ['rgba(255, 99, 132,0.1)','grey','pink','orange'],
          borderColor: 'rgb(255, 99, 132)',
          data: [0, 10, 5, 2]
        }]
      },

      // Configuration options go here
      options: {}
    });
  });