<?PHP

session_start();

$uname = $_SESSION["name"];
// $uname = "user2";

$host="localhost";
$port=3306;
$user="root";
$password="root";
$dbname="ad_trial";

$con = new mysqli($host, $user, $password, $dbname, $port)
	or die ('Could not connect to the database server' . mysqli_connect_error());

if ($con->connect_error)
{
    echo("Connection Fail");
}
else
{
    echo("<p>Connection Successfull!!<p>");
}

$dur = $_POST["card"];

if ($dur == 1)
    $cost = 199;
elseif ($dur == 6)
    $cost = 499;
elseif ($dur == 12)
    $cost = 999;

echo ("<p>You have Bought $dur months of subscription worth Rs $cost<p>");

$sql = "INSERT INTO `ad_trial`.`regist`(`u_name`,`pay_date`,`dur`,`amt`,`recur`) VALUES('$uname',current_date(),'$dur','$cost','1')";

echo("<p>$uname</p>");

if ($con->query($sql) === true)
{
    echo ("<p><b>Inserted Successfully </b></p>");
}
else
{
    echo ("<p><b>Failed to insert </b></p>");
}

?>
