<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tracking</title>
</head>

<body>
  <style>
    <?php include 'font.css'; ?>
  </style>
  <div>
    <?php include 'body.html'; ?>
  </div>
  <script>
    <?php include 'animation.js'; ?>
  </script>
  <br>
  <form method="POST">
    <p>Enter Username: <input type="text" name="user"></p>
    <p><input type="submit" value="Submit"></p>
  </form>

  <?php
  require_once "pdo.php";
  $sql = "Select * from event_status where event_id in ( select event_id from event_details where username = :user)";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array(':user' => $_POST['user']));
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  print_r($row);

  include "animation.php";
  ?>
</body>

</html>';