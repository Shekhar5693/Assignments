<?php
session_start();
if ( ! isset($_SESSION['username']) ) {
    die('<h1><a href="Login/main_login.php">Please log in</a></h1>');
}

?>